import unittest,tempfile,sqlite3,json,hashlib,zipfile
from pathlib import Path
from transfer_assets import import_assets

class TransferTests(unittest.TestCase):
    def test_roundtrip_preserves_bytes_and_timestamp(self):
        with tempfile.TemporaryDirectory() as td:
            td=Path(td);content=b'entity_id\tname\nS1-1\tx\n';stamp=1723456789000000000
            manifest={'version':1,'files':[{'path':'data/normalized/test.tsv','bytes':len(content),'sha256':hashlib.sha256(content).hexdigest(),'mtime_ns':stamp}]}
            archive=td/'a.zip'
            with zipfile.ZipFile(archive,'w') as z:z.writestr('transfer_manifest.json',json.dumps(manifest));z.writestr('data/normalized/test.tsv',content)
            import_assets(td/'received',archive);dest=td/'received/data/normalized/test.tsv'
            self.assertEqual(dest.read_bytes(),content);self.assertEqual(dest.stat().st_mtime_ns,stamp)
            with self.assertRaises(FileExistsError):import_assets(td/'received',archive)
    def test_corrupt_content_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            td=Path(td);archive=td/'a.zip';manifest={'version':1,'files':[{'path':'data/x','bytes':1,'sha256':'0'*64,'mtime_ns':0}]}
            with zipfile.ZipFile(archive,'w') as z:z.writestr('transfer_manifest.json',json.dumps(manifest));z.writestr('data/x',b'x')
            with self.assertRaises(ValueError):import_assets(td/'received',archive)
            self.assertFalse((td/'received/data/x').exists())

class FeatureTests(unittest.TestCase):
    def test_single_candidate_and_missing_address(self):
        from context_features import context
        import numpy as np
        rows=[{'name_sorted':'shop','addr_norm':'','entity_id':'S2-1'},{'name_sorted':'shop','addr_norm':'','entity_id':'S3-2'}]
        self.assertTrue(np.array_equal(context(rows[:1]),np.zeros((1,12))))
        result=context(rows);self.assertEqual(result[0,1],0);self.assertEqual(result[0,7],0)
    def test_reference_excludes_own_s1(self):
        from competition import Reference
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'ref.sqlite';db=sqlite3.connect(path)
            db.execute('CREATE TABLE refs(eid,name,ns,address,body,country)')
            db.execute('INSERT INTO refs VALUES (?,?,?,?,?,?)',('S1-1','shop','shop','12 main street','main street','us'));db.commit();db.close()
            reference=Reference(path);q={'entity_id':'S1-1','name_sorted':'shop','name_nospace':'shop','addr_norm':'12 main street'}
            f=reference.features(q,q);self.assertEqual(len(f),32);self.assertEqual(f[4],0);reference.db.close()
    def test_packaged_models_load(self):
        import matching_v4 as v4
        model=json.loads((Path(__file__).resolve().parents[1]/'models/model_v4.json').read_text())
        for key,width in [('model_text',153),('context_model_text',197),('cascade_model_text',22)]:
            self.assertEqual(v4.v.model_booster(model[key]).num_feature(),width)

if __name__=='__main__':unittest.main()
