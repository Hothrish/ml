# BuildOne v4 — reuse the completed indexes

This is an experimental improvement over the submitted v3 system (public score 0.9249). It adds 32 features comparing each candidate with competing S1 records and 12 features measuring agreement between candidate records. It uses the existing v3 normalizer, retrieval indexes, cheap classifier and base classifier, then applies a newly trained LightGBM classifier to plausible candidates. The new threshold was chosen on calibration data. Singleton entities are included in the macro F0.5 calculation.

The delivered pipeline scored **0.956341**, compared with **0.945437** for v3, on the same 2,000-entity audit. True positives increased from 6,056 to 6,291; false positives increased from 76 to 100. Both correctly left 103 of 109 singleton rows empty. See `reports/production_audit.json`. The cached-feature audit is a separate diagnostic. These local scores are not leaderboard predictions; France has no labeled training examples, and 0.985/0.99 is not established.

## What needs to run again?

- Normalization: **no**, if the existing normalized files are transferred unchanged.
- S2/S3 record index and LSH index construction: **no**.
- Training: **no**; the fitted models are included.
- New S1 reference lookup: **once**. It uses normalized S1 names/addresses, not labels.
- Prediction: **yes, all test S1 entities**, because the classifier changed.
- Validation: **yes**, after prediction; the runner does this automatically.

The v3 final TSVs do not contain the comparison features, candidate retrieval evidence, or model scores needed by v4. They cannot substitute for the indexed data. Do not resume a v3 checkpoint with v4. A v4 prediction can resume its own completed shards by repeating exactly the same command.

## Send to your friend

Send both `BuildOne_v4.zip` (code/models) and the separate asset archive created below. Do not send the training data. The assets total approximately **9.67 GB**, so use cloud storage or an external drive. Allow room for both the archive and extracted assets, plus new output shards and merged output; 40 GB free is a practical minimum.

Extract the code ZIP first. Open PowerShell in the extracted `BuildOne_v4` folder. On the current computer, export the existing inference assets:

```powershell
py -3 run.py export --data-root "C:\student_resource\student_resource" --archive "C:\student_resource\BuildOne_test_assets.zip"
```

Export uses Python's standard library. It reads the completed indexes and creates a separate archive. It includes normalized test S1/S2/S3 files, the record index, compact record and LSH arrays, and the country cache. The full SQLite LSH band table is replaced in the archive with its small metadata database; the compact arrays contain all lookup postings. It does not change your original indexes.

## Friend: installation and import

Use 64-bit Python 3.12, an SSD, and preferably at least 16 GB RAM. Open PowerShell inside the extracted `BuildOne_v4` code folder:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe run.py import --data-root "D:\BuildOne_data" --archive "D:\Downloads\BuildOne_test_assets.zip"
.\.venv\Scripts\python.exe run.py tests --data-root "D:\BuildOne_data"
.\.venv\Scripts\python.exe run.py check --data-root "D:\BuildOne_data"
```

Change the `D:` paths to your friend's actual locations. Import into a fresh data directory. Use the supplied importer, not Windows Extract All: it verifies SHA256 and restores the original nanosecond timestamps required by the index manifests. If an import is interrupted, choose a fresh destination for the retry.

On a computer that already has all the original assets, skip export/import and set `--data-root` to that existing project. Existing `.matching_deps` can be used if compatible with the selected Python; the clean virtual environment above is recommended for another computer.

## Benchmark, then full prediction

```powershell
.\.venv\Scripts\python.exe run.py benchmark --data-root "D:\BuildOne_data" --workers 4
```

This builds the new S1 lookup once, then predicts the first 2,000 S1 records. It reports throughput and a rough full-run estimate. These first records need not represent all countries or difficult cases; disk speed, RAM and concurrent jobs affect runtime. Benchmark output is partial and must not be submitted. To repeat a benchmark after changing worker count, use a fresh `--out` folder so saved shards are not reused.

If the benchmark finishes successfully, run:

```powershell
.\.venv\Scripts\python.exe run.py predict --data-root "D:\BuildOne_data" --workers 4
```

Start with four worker processes. A machine with sufficient free RAM and CPU capacity can benchmark eight using `--workers 8 --out "D:\BuildOne_data\benchmark_v4_8workers"`. More processes are not guaranteed to be faster. During local validation, memory use was measured at 94% with less than 1 GB available, and the short test benchmark was only 4 S1/s. This release has **not demonstrated a speedup** over v3. Measure on the friend's machine before committing to the full run; the added context classifier has extra work to do.

The full run writes:

```text
D:\BuildOne_data\output_v4\matching_results.tsv
D:\BuildOne_data\output_v4\candidate_pairs.tsv
D:\BuildOne_data\output_v4\prediction_report.json
```

Upload only the completed, validated `matching_results.tsv` to the leaderboard. Retain both TSVs for the final submission package. Every listed candidate is scored by the cheap classifier; retained candidates receive the base classifier and plausible candidates receive the final context classifier. Matches are a subset of the listed candidate set. The streaming validator checks headers, complete S1 coverage, source ID prefixes, duplicate IDs within rows and candidate membership. Candidate IDs originate from the checked record index; the validator does not separately reread all raw target IDs.

Repeating `predict` with the same settings resumes v4 shards. To use changed models/code, use a fresh output directory. Do not mix outputs from Claude's experiments with this runner unless you separately evaluate and document the combination.

## Evidence and limitations

The original training sample contains 12,000 S1 records, split into 8,000 fit, 2,000 calibration and 2,000 audit entities. The new classifier uses candidates whose original full-model probability is at least 0.001; its training features have 197 columns. Candidate-to-candidate context is computed only within that plausible set. S1 reference comparisons exclude the current S1 itself. Exact reference buckets larger than 50 are represented by count features and are not expanded.

The audit has been used to compare earlier versions, so it is a development benchmark rather than a completely untouched final estimate. The held-out countries and public leaderboard can differ. This release improves classification; it retains v3 retrieval and its remaining recall limitations. It does not use blanket country-specific match counts, force a singleton percentage, enforce an unvalidated graph closure, or assume an intersection ensemble improves the score.

`src/train_v3.py` and `src/train_cascade_v3.py` reproduce the base feature/training stages. `src/train_context.py` reproduces the new fit/calibration stage from the v3 candidate-feature dataset and normalized S1 sample. It writes a new model file rather than replacing the supplied one. All production inference modules and fitted model parameters are included.
