"""V3 retrieval followed by a calibrated S1-competition/context classifier."""
import os
import numpy as np
import matching_v3 as v
from functools import lru_cache
from competition import Reference
from context_features import context

_reference=None
# Three boosters are used per query; a two-entry cache would reload every model.
v.model_booster=lru_cache(maxsize=4)(v.model_booster.__wrapped__)

def predict_one(q):
    global _reference
    model=v.v.m._MODEL
    if _reference is None:_reference=Reference(os.environ['MATCH_REFERENCE_INDEX'])
    candidates,_=v.v.m._BLOCKER.retrieve(q)
    ids=[r['entity_id'] for r in candidates]
    if not candidates:return q['entity_id'],[],[]
    records=[r['matching_record'] for r in candidates]
    gate=v.model_booster(model['cascade_model_text']).predict(v.cheap_features(q,records),num_threads=1)
    chosen=np.flatnonzero(gate>=model['cascade_threshold']);views=v.query_views(q)
    if not len(chosen):return q['entity_id'],ids,[]
    x=np.asarray([v.features(q,records[i],candidates[i]['routes'],candidates[i]['fusion_score'],views) for i in chosen],dtype=np.float32)
    base=v.predict_scores(x,model);keep=np.flatnonzero(base>=model['context_prefilter'])
    if not len(keep):return q['entity_id'],ids,[]
    rr=[records[chosen[i]] for i in keep]
    extra=np.asarray([_reference.features(q,r) for r in rr],dtype=np.float32)
    xx=np.column_stack([x[keep],extra,context(rr)])
    if xx.shape[1]!=model['context_feature_count']:raise ValueError('Context feature schema mismatch')
    scores=v.model_booster(model['context_model_text']).predict(xx,num_threads=1)
    return q['entity_id'],ids,[ids[chosen[i]] for i,p in zip(keep,scores) if p>=model['context_threshold']]

v.v.m.predict_one=predict_one

if __name__=='__main__':v.main()
