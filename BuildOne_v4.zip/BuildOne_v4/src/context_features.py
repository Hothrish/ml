import numpy as np
from rapidfuzz import fuzz,process

def context(records):
    n=len(records)
    if n<2:return np.zeros((n,12),dtype=np.float32)
    names=[r['name_sorted'] for r in records];addresses=[r['addr_norm'] for r in records]
    name=process.cdist(names,names,scorer=fuzz.ratio,dtype=np.float64,workers=1)/100
    addr=process.cdist(addresses,addresses,scorer=fuzz.token_sort_ratio,dtype=np.float64,workers=1)/100
    valid=np.asarray([bool(a) for a in addresses]);addr*=valid[:,None]&valid[None,:]
    np.fill_diagonal(name,0);np.fill_diagonal(addr,0)
    product=name*addr;combined=(name+addr)/2;source=np.asarray([r['entity_id'].startswith('S3-') for r in records]);cross=source[:,None]!=source[None,:]
    return np.column_stack([name.max(axis=1),addr.max(axis=1),product.max(axis=1),combined.max(axis=1),
        (name>.9).sum(axis=1)/10,(addr>.9).sum(axis=1)/10,((name>.8)&(addr>.8)).sum(axis=1)/10,
        (product*cross).max(axis=1),(combined*cross).max(axis=1),
        np.sort(product,axis=1)[:,-2:].mean(axis=1),np.sort(combined,axis=1)[:,-2:].mean(axis=1),np.full(n,min(n,50)/50)]).astype(np.float32)
