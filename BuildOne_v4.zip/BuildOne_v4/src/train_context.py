"""Reproduce context fitting from the existing v3 feature dataset; no audit tuning."""
from pathlib import Path
import argparse,json,time
import numpy as np
import matching_v3 as v
from competition import Reference
from context_features import context
from reference_index import build

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('dataset','queries','index','records','normalized-dir','reference','base-model','out'):p.add_argument('--'+key,type=Path,required=True)
    p.add_argument('--workers',type=int,default=2);a=p.parse_args()
    if a.out.exists():raise FileExistsError('Choose a fresh model output path')
    start=time.monotonic();meta=json.loads((a.dataset/'dataset.json').read_text());base=json.loads(a.base_model.read_text())
    groups=np.load(a.dataset/'groups.npy');rids=np.load(a.dataset/'rids.npy');y=np.load(a.dataset/'y.npy')
    queries={q['entity_id']:q for q in v.b.iter_records([a.queries],1)}
    build(a.normalized_dir,'train',a.reference);reference=Reference(a.reference)
    db=v.b.connect(a.index,readonly=True);lookup=v.RecordLookup(a.records,v.b.get_meta(db));db.close()
    booster=v.model_booster(base['model_text']);parts={}
    for split in ('fit','calibration'):
        wanted=set(meta['splits'][split]);mask=np.asarray([q in wanted for q in meta['queries']])[groups];indices=[];blocks=[]
        for begin in range(0,len(groups),50000):
            ix=np.flatnonzero(mask[begin:begin+50000])+begin
            if not len(ix):continue
            raw=np.load(a.dataset/'x.npy',mmap_mode='r');x=raw[ix].copy();raw._mmap.close()
            keep=booster.predict(x,num_threads=a.workers)>=.001
            indices.extend(ix[keep]);blocks.append(x[keep])
        indices=np.asarray(indices,dtype=np.int64);x=np.concatenate(blocks);gg=groups[indices]
        extra=np.empty((len(indices),44),np.float32);bounds=np.r_[0,np.flatnonzero(gg[1:]!=gg[:-1])+1,len(gg)]
        for lo,hi in zip(bounds[:-1],bounds[1:]):
            q=queries[meta['queries'][gg[lo]]];rr=[lookup.get(int(rids[i])) for i in indices[lo:hi]]
            extra[lo:hi,:32]=[reference.features(q,r) for r in rr];extra[lo:hi,32:]=context(rr)
        parts[split]=(np.column_stack([x,extra]),y[indices],[meta['queries'][i] for i in gg])
        print('Prepared',split,len(indices),flush=True)
    xf,yf,_=parts['fit'];xc,yc,gc=parts['calibration']
    train=v.v.lgb.Dataset(xf,label=yf);valid=v.v.lgb.Dataset(xc,label=yc,reference=train)
    params={'objective':'binary','metric':'binary_logloss','num_leaves':31,'learning_rate':.04,'min_data_in_leaf':50,'lambda_l2':5,'feature_fraction':.9,'num_threads':a.workers,'verbosity':-1,'seed':81,'deterministic':True,'force_col_wise':True}
    fitted=v.v.lgb.train(params,train,num_boost_round=900,valid_sets=[valid],callbacks=[v.v.lgb.early_stopping(80,verbose=False),v.v.lgb.log_evaluation(100)])
    truth=dict(zip(meta['queries'],meta['truth']));cal={q:truth[q] for q in meta['splits']['calibration']}
    score,threshold=v.v.select_threshold(fitted.predict(xc,num_threads=a.workers),gc,yc,cal)
    base.update(context_model_text=fitted.model_to_string(),context_threshold=threshold,context_prefilter=.001,context_feature_count=197,delivery_version='BuildOne v4 reproduced')
    a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(base),encoding='utf-8')
    report={'calibration_macro_f0_5':score,'threshold':threshold,'iterations':fitted.best_iteration,'fit_pairs':len(yf),'calibration_pairs':len(yc),'seconds':time.monotonic()-start,'audit_used_for_training':False}
    Path(str(a.out)+'.report.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report,indent=2))

if __name__=='__main__':main()
