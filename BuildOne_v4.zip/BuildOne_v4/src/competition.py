from functools import lru_cache
from pathlib import Path
import sqlite3,re,math
from rapidfuzz import fuzz

class Reference:
    def __init__(self,path):
        self.db=sqlite3.connect(Path(path).resolve().as_uri()+'?mode=ro',uri=True)
        self.db.execute('PRAGMA cache_size=-65536')
        self.db.execute('PRAGMA mmap_size=2147483648')
        self.find=lru_cache(maxsize=20000)(self._find)
    def _find(self,field,value):
        if not value:return ()
        rows=self.db.execute(f'SELECT eid,name,ns,address,body,country FROM refs WHERE {field}=? LIMIT 51',(value,)).fetchall()
        return tuple(rows) if len(rows)<=50 else None
    def candidates(self,r):
        body=' '.join(re.sub(r'\d+',' ',r['addr_norm']).split());all_rows={};counts=[]
        for field,value in [('name',r['name_sorted']),('ns',r['name_nospace']),('address',r['addr_norm']),('body',body if len(body)>12 else '')]:
            rows=self.find(field,value);counts.append(51 if rows is None else len(rows))
            if rows:all_rows.update((row[0],row) for row in rows)
        return tuple(all_rows.values()),counts
    def features(self,q,r):
        candidates,counts=self.candidates(r)
        def compare(name,ns,address):
            n=max(fuzz.ratio(name,r['name_sorted']),fuzz.ratio(ns,r['name_nospace']))/100
            a=max(fuzz.ratio(address,r['addr_norm']),fuzz.token_sort_ratio(address,r['addr_norm']))/100 if address and r['addr_norm'] else 0.
            nsame=float(bool(ns) and ns==r['name_nospace']);asame=float(bool(address) and address==r['addr_norm'])
            nums=set(re.findall(r'\d+',address));rnums=set(re.findall(r'\d+',r['addr_norm']))
            num=len(nums&rnums)/len(nums|rnums) if nums and rnums else 0.
            return (n,a,(n+a)/2,.75*n+.25*a,.25*n+.75*a,n*a,nsame,asame,num)
        own=compare(q['name_sorted'],q['name_nospace'],q['addr_norm'])
        rivals=[compare(name,ns,address) for eid,name,ns,address,body,country in candidates if eid!=q['entity_id']]
        maximum=[max((s[i] for s in rivals),default=0.) for i in range(len(own))]
        best=max(rivals,key=lambda s:s[2],default=(0.,)*len(own))
        return [math.log1p(c) for c in counts]+[min(len(rivals),50)/50]+maximum+[a-b for a,b in zip(own,maximum)]+list(best)
