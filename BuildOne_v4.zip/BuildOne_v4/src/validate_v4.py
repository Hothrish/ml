"""Stream complete S1 coverage and candidate membership without loading 378M pairs."""
from itertools import zip_longest
import json
import blocking as b
from validate_matching_v3 import check_candidates

def validate(out,norm):
    report=json.loads((out/'prediction_report.json').read_text())
    if report['partial'] or report['split']!='test':raise ValueError('Partial or non-test output is not a submission')
    check_candidates(out/'matching_results.tsv',out/'candidate_pairs.tsv')
    n=empty=0
    with open(out/'matching_results.tsv',encoding='utf-8') as f:
        next(f)
        for q,line in zip_longest(b.iter_records(b.source_parts(norm,'test',1),1),f):
            if q is None or line is None:raise ValueError('S1 coverage mismatch')
            eid,matches=line.rstrip('\r\n').split('\t')
            if eid!=q['entity_id']:raise ValueError('S1 order or coverage mismatch')
            ids=matches.split(',') if matches else []
            if len(ids)!=len(set(ids)):raise ValueError('Duplicate matched target')
            if any(not s.startswith(('S2-','S3-')) or s.strip()!=s for s in ids):raise ValueError('Invalid matched target')
            n+=1;empty+=not ids
    if n!=report['s1_records']:raise ValueError('Prediction report row count differs')
    print(f'PASS: {n:,} S1 rows, {empty:,} empty; matches are a subset of scored candidates. IDs originate from the validated record index.',flush=True)
