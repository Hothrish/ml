"""Build a bounded exact lookup of all S1 covariates; no labels used."""
from pathlib import Path
import json,re,sqlite3,time
import blocking as b

def build(normalized,split,dest):
    dest=Path(dest);paths=b.source_parts(normalized,split,1);identity={'split':split,'inputs':b.fingerprint(paths),'version':1}
    if dest.exists():
        db=sqlite3.connect(dest.resolve().as_uri()+'?mode=ro',uri=True)
        saved=json.loads(db.execute('SELECT value FROM meta').fetchone()[0]);db.close()
        if any(saved.get(k)!=value for k,value in identity.items()):raise ValueError('S1 reference does not match normalized input; use a fresh reference path')
        print('PASS: S1 reference',saved['rows'],flush=True);return
    dest.parent.mkdir(parents=True,exist_ok=True);tmp=Path(str(dest)+'.partial')
    if tmp.exists():tmp.unlink()
    db=sqlite3.connect(tmp);db.execute('PRAGMA journal_mode=OFF');db.execute('PRAGMA synchronous=OFF');db.execute('PRAGMA cache_size=-65536')
    db.execute('CREATE TABLE refs(eid TEXT NOT NULL,name TEXT NOT NULL,ns TEXT NOT NULL,address TEXT NOT NULL,body TEXT NOT NULL,country TEXT NOT NULL)')
    batch=[];start=time.monotonic();n=0
    for n,q in enumerate(b.iter_records(paths,1),1):
        body=' '.join(re.sub(r'\d+',' ',q['addr_norm']).split())
        batch.append((q['entity_id'],q['name_sorted'],q['name_nospace'],q['addr_norm'],body,q['country_norm'].casefold()))
        if len(batch)>=10000:db.executemany('INSERT INTO refs VALUES (?,?,?,?,?,?)',batch);batch=[]
        if n%250000==0:print(f'S1 reference: {n:,}; {time.monotonic()-start:.1f}s',flush=True)
    if batch:db.executemany('INSERT INTO refs VALUES (?,?,?,?,?,?)',batch)
    for field in ('name','ns','address','body'):
        print('Indexing S1',field,flush=True);db.execute(f'CREATE INDEX i_{field} ON refs({field})')
    db.execute('CREATE TABLE meta(value TEXT)');db.execute('INSERT INTO meta VALUES (?)',(json.dumps(dict(identity,rows=n,seconds=time.monotonic()-start)),))
    db.commit();db.close();tmp.replace(dest);print('S1 reference ready',n,flush=True)
