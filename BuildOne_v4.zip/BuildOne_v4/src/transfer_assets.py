"""Transfer only inference assets, with SHA256 and original nanosecond timestamps."""
from pathlib import Path,PurePosixPath
import hashlib,json,os,sqlite3,tempfile,time,zipfile

def asset_paths(root):
    from blocking import source_parts
    paths=[]
    for source in (1,2,3):paths+=source_parts(root/'data/normalized','test',source)
    paths.append(root/'runs/test_match.sqlite')
    for prefix,extensions in [('test_compact_v3',('json','keys','offsets','rids')),('test_records_v3',('json','data','offsets')),('test_countries_v3',('json','bin'))]:
        paths += [root/'runs'/f'{prefix}.{ext}' for ext in extensions]
    for path in paths:
        if not path.is_file():raise FileNotFoundError(path)
    return paths

def export_assets(root,archive):
    from blocking import check_index,check_lsh
    archive=Path(archive).resolve();archive.parent.mkdir(parents=True,exist_ok=True)
    if archive.exists():raise FileExistsError('Archive already exists; choose a new name')
    paths=asset_paths(root);check_index(root/'runs/test_match.sqlite',root/'data/normalized','test')
    lsh_meta=check_lsh(root/'runs/test_match_lsh_b8.sqlite',root/'runs/test_match.sqlite')
    for database in ('test_match.sqlite','test_match_lsh_b8.sqlite'):
        for suffix in ('-wal','-journal'):
            sidecar=root/'runs'/(database+suffix)
            if sidecar.exists() and sidecar.stat().st_size:raise ValueError('Index has an active journal. Finish index writes before exporting.')
    manifest={'version':1,'kind':'BuildOne v4 test inference assets','files':[]}
    temporary=Path(str(archive)+'.partial');start=time.monotonic()
    # Compact arrays contain the complete band lookup. SQLite band rows are redundant.
    with tempfile.TemporaryDirectory(prefix='buildone-transfer-') as td:
        stub=Path(td)/'lsh.sqlite';db=sqlite3.connect(stub)
        db.execute('CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT)')
        db.execute('INSERT INTO metadata VALUES (?,?)',('manifest',json.dumps(lsh_meta)))
        db.execute('INSERT INTO metadata VALUES (?,?)',('compact_only','true'))
        db.commit();db.close()
        items=[(p,p.relative_to(root).as_posix()) for p in paths]+[(stub,'runs/test_match_lsh_b8.sqlite')]
        print(f'Exporting {sum(p.stat().st_size for p,_ in items)/1e9:.2f} GB. No train data or full SQLite LSH bands needed.',flush=True)
        with zipfile.ZipFile(temporary,'w',compression=zipfile.ZIP_STORED,allowZip64=True) as z:
            for path,name in items:
                before=path.stat();digest=hashlib.sha256();size=0
                with path.open('rb') as src,z.open(name,'w',force_zip64=True) as dest:
                    while block:=src.read(8*1024*1024):dest.write(block);digest.update(block);size+=len(block)
                after=path.stat()
                if before.st_size!=after.st_size or before.st_mtime_ns!=after.st_mtime_ns:raise ValueError(f'File changed during export: {name}')
                manifest['files'].append({'path':name,'bytes':size,'sha256':digest.hexdigest(),'mtime_ns':before.st_mtime_ns})
                print('Packed',name,flush=True)
            z.writestr('transfer_manifest.json',json.dumps(manifest,indent=2))
    temporary.replace(archive);print(f'Export ready: {archive}; {time.monotonic()-start:.1f}s',flush=True)

def import_assets(root,archive):
    root=Path(root).resolve();root.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        manifest=json.loads(z.read('transfer_manifest.json'))
        if manifest.get('version')!=1:raise ValueError('Unknown asset archive version')
        entries=[];seen=set()
        for entry in manifest['files']:
            rel=PurePosixPath(entry['path'])
            if rel.is_absolute() or '..' in rel.parts or '\\' in str(rel) or ':' in str(rel):raise ValueError('Unsafe archive path')
            dest=root.joinpath(*rel.parts).resolve()
            if not dest.is_relative_to(root) or str(rel) in seen:raise ValueError('Invalid or repeated archive path')
            seen.add(str(rel))
            if dest.exists():raise FileExistsError(f'Import into an empty data root: {dest} already exists')
            if z.getinfo(str(rel)).file_size!=entry['bytes']:raise ValueError('Archive size mismatch')
            entries.append((entry,dest))
        for entry,dest in entries:
            dest.parent.mkdir(parents=True,exist_ok=True);tmp=Path(str(dest)+'.partial');digest=hashlib.sha256()
            with z.open(entry['path']) as src,tmp.open('wb') as output:
                while block:=src.read(8*1024*1024):output.write(block);digest.update(block)
            if digest.hexdigest()!=entry['sha256']:raise ValueError(f'Checksum failed: {entry["path"]}')
            os.utime(tmp,ns=(entry['mtime_ns'],entry['mtime_ns']));tmp.replace(dest)
            print('Verified',entry['path'],flush=True)
    (root/'transfer_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print('Imported and verified. Run check, then benchmark.',flush=True)
