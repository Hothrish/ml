"""Portable entry point. Run python run.py --help."""
from pathlib import Path
import argparse,json,os,sys,time,subprocess
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('stage',choices=['check','prepare','benchmark','predict','validate','tests','export','import'])
    p.add_argument('--data-root',type=Path,required=True)
    p.add_argument('--workers',type=int,default=4)
    p.add_argument('--deps',type=Path)
    p.add_argument('--out',type=Path)
    p.add_argument('--archive',type=Path)
    p.add_argument('--reference-index',type=Path,help='Optional separate location for the new S1 lookup')
    p.add_argument('--limit',type=int,default=2000)
    a=p.parse_args();a.data_root=a.data_root.resolve()
    deps=a.deps or a.data_root/'.matching_deps'
    if deps.is_dir():sys.path.insert(0,str(deps));os.environ['PYTHONPATH']=str(deps)+os.pathsep+os.environ.get('PYTHONPATH','')
    if a.stage in ('export','import'):
        from transfer_assets import export_assets,import_assets
        if not a.archive:p.error('--archive is required')
        (export_assets if a.stage=='export' else import_assets)(a.data_root,a.archive);return
    if a.stage=='tests':
        import unittest
        result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.discover(str(ROOT/'tests')))
        if not result.wasSuccessful():raise SystemExit(1)
        return
    import matching_v4 as v4
    if os.name=='nt':
        import ctypes
        class MemoryStatus(ctypes.Structure):
            _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(name,ctypes.c_ulonglong) for name in ('total','available','page','availablepage','virtual','availablevirtual','extended')]
        memory=MemoryStatus();memory.length=ctypes.sizeof(memory)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(memory)):
            print(f'RAM in use: {memory.load}%; available: {memory.available/1e9:.2f} GB',flush=True)
            if memory.load>=90:print('RAM pressure is high. Benchmark estimates may be dominated by disk paging; use a machine with more free memory for a full run.',flush=True)
    v=v4.v;runs=a.data_root/'runs';norm=a.data_root/'data/normalized'
    model=ROOT/'models/model_v4.json';index=runs/'test_match.sqlite';lsh=runs/'test_match_lsh_b8.sqlite'
    compact=runs/'test_compact_v3';records=runs/'test_records_v3';countries=runs/'test_countries_v3';reference=(a.reference_index or runs/'test_reference_v4.sqlite').resolve()
    output=(a.out or a.data_root/('benchmark_v4' if a.stage=='benchmark' else 'output_v4')).resolve()
    if a.stage=='validate':
        from validate_v4 import validate
        validate(output,norm);return
    if a.workers<1:p.error('--workers must be positive')
    os.environ.update(MATCH_COMPACT_LSH=str(compact),MATCH_COMPACT_RECORDS=str(records),MATCH_COUNTRY_CACHE=str(countries),MATCH_REFERENCE_INDEX=str(reference))
    meta=v.b.check_index(index,norm,'test')
    settings=json.loads(model.read_text(encoding='utf-8'))
    os.environ.update(MATCH_TEXT_RERANK='1',MATCH_POOL_RARITY='1',MATCH_RERANK_POOL=str(settings['rerank_pool']))
    check=v.CompactLSHBlocker(index,lsh,v.b.Config(**settings['config']));check.close()
    v.model_booster(settings['model_text']);v.model_booster(settings['context_model_text'])
    print('PASS: model, normalized files and completed test indexes',sum(meta['rows'].values()),flush=True)
    if a.stage=='check':return
    from reference_index import build
    build(norm,'test',reference)
    if a.stage=='prepare':return
    # Identity includes the reference contents' input identity and the delivered code.
    # The lower-level runner fingerprints the model, normalized inputs and shard policy.
    identity={'reference_meta':json.loads(__import__('sqlite3').connect(reference).execute('SELECT value FROM meta').fetchone()[0]),
              'code_sha256':{f.name:__import__('hashlib').sha256(f.read_bytes()).hexdigest() for f in sorted((ROOT/'src').glob('*.py'))}}
    output.mkdir(parents=True,exist_ok=True);policy=output/'v4_identity.json'
    if policy.exists() and json.loads(policy.read_text())!=identity:raise ValueError('Output belongs to different v4 code/reference; choose --out with a fresh path')
    if not policy.exists() and (output/'checkpoint.json').exists():raise ValueError('Output is an older run; choose a fresh --out')
    policy.write_text(json.dumps(identity,indent=2),encoding='utf-8')
    args=['predict','--index',str(index),'--lsh-index',str(lsh),'--normalized-dir',str(norm),'--split','test',
          '--model',str(model),'--compact-index',str(compact),'--compact-records',str(records),'--country-cache',str(countries),
          '--out',str(output),'--workers',str(a.workers)]
    if a.stage=='benchmark':args+=['--limit',str(a.limit)]
    sys.argv=[str(ROOT/'src/matching_v4.py')]+args;v.main()
    if a.stage=='predict':
        from validate_v4 import validate
        validate(output,norm)
    else:
        stats=json.loads((output/'prediction_report.json').read_text());seconds=stats['seconds_this_run'];n=stats['new_s1_this_run']
        if n:print(f'Benchmark {n/seconds:.1f} S1/s. At that rate 1,732,544 S1 would take {1732544*seconds/n/3600:.2f} hours; full-run speed can differ.',flush=True)
        print('Benchmark output is PARTIAL: do not upload it.',flush=True)

if __name__=='__main__':main()
